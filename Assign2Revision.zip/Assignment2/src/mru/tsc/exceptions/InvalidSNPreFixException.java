package mru.tsc.exceptions;

public class InvalidSNPreFixException extends Exception{
	
	public InvalidSNPreFixException (String message) {
		super(message);
	}

}
