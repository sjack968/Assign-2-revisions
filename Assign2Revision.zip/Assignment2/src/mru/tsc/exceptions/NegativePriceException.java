package mru.tsc.exceptions;

public class NegativePriceException extends Exception {
	
    public NegativePriceException(String message) {
        super(message);
    }
}