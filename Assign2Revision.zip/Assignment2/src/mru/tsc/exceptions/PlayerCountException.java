package mru.tsc.exceptions;

public class PlayerCountException extends Exception {
	
    public PlayerCountException(String message) {
        super(message);
    }
}