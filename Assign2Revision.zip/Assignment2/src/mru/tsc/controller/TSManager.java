package mru.tsc.controller;

import java.io.*;
import java.util.*;
import mru.tsc.model.*;
import mru.tsc.exceptions.InvalidSNPreFixException;
import mru.tsc.exceptions.NegativePriceException; 
import mru.tsc.exceptions.PlayerCountException;   

public class TSManager {

    private static final String FILE_PATH = "res/toys.txt";
    private List<Toy> toys;
    private Scanner input;

    /**
     * Class constructor
     * creates an array list called toys
     * creates a input scanner called input
     * 
     */
    
    public TSManager() {
        toys = new ArrayList<>();
        input = new Scanner(System.in);
        loadToys();
    }

    /**
     * Public class used for defining how the search and purchase of toys will be done
     * prints out options for the user to choose from to begin search
     * narrows down search by asking for serial number, part of the name, andtoy type.
     * gives invalid if toy does not exist
     * finishes  y giving purchase amount
     * 
     */
    public void searchAndPurchaseToy() {
        System.out.println("\nSearch by:");
        System.out.println("1. Serial Number");
        System.out.println("2. Name");
        System.out.println("3. Type");
        int choice = getIntInput("Choose an option: ");

        List<Toy> results = new ArrayList<>();
        switch (choice) {
            case 1 -> {
                String sn = getStringInput("Enter Serial Number: ");
                toys.stream().filter(t -> t.getSerialNumber().equalsIgnoreCase(sn)).forEach(results::add);
            }
            case 2 -> {
                String name = getStringInput("Enter part of name: ");
                toys.stream().filter(t -> t.getName().toLowerCase().contains(name.toLowerCase())).forEach(results::add);
            }
            case 3 -> {
                String type = getStringInput("Enter toy type (Animal, Figure, Puzzle, BoardGame): ");
                toys.stream().filter(t -> t.getClass().getSimpleName().equalsIgnoreCase(type)).forEach(results::add);
            }
            default -> {
                System.out.println("Invalid option.");
                return;
            }
        }

        if (results.isEmpty()) {
            System.out.println("No toys found.");
            return;
        }

        System.out.println("\nSearch Results:");
        for (int i = 0; i < results.size(); i++) {
            System.out.printf("[%d] %s%n", i + 1, results.get(i));
        }

        int purchaseIndex = getIntInput("\nEnter number to purchase or 0 to return: ");
        if (purchaseIndex > 0 && purchaseIndex <= results.size()) {
            Toy selected = results.get(purchaseIndex - 1);
            if (selected.getAvailableCount() > 0) {
                selected.setAvailableCount(selected.getAvailableCount() - 1);
                System.out.println("Purchase successful! Remaining count: " + selected.getAvailableCount());
            } else {
                System.out.println("Sorry, this toy is out of stock!");
            }
        }
    }

    /**
     * public class to determine how a toy is added
     * prompts for type of toy and serial number
     * if the serial number is already taken is prompted invalid
     * aks user for various desriters for the toy
     * adds toy 
     * 
     */
    public void addToy() {
        System.out.println("\nAdding new toy:");
        String type = getStringInput("Enter type (Animal, Figure, Puzzle, BoardGame): ");
        String sn = getStringInput("Enter Serial Number: ");

                for (Toy t : toys) {
            if (t.getSerialNumber().equalsIgnoreCase(sn)) {
                System.out.println("Error: Serial Number already exists!");
                return;
            }
        }
                try {
                    validateSNPrefix(type, sn);
                } catch (InvalidSNPreFixException e) {
                    System.out.println("Error: " + e.getMessage());
                    return; 
                }

        String name = getStringInput("Enter name: ");
        String brand = getStringInput("Enter brand: ");
        double price = getDoubleInput("Enter price: ");
        
        try {
            if (price < 0) {
                throw new NegativePriceException("Price cannot be negative!");
            }
        } catch (NegativePriceException e) {
            System.out.println("Error: " + e.getMessage());
            return;
        }
        
        int count = getIntInput("Enter available count: ");
        String age = getStringInput("Enter age range: ");

        try {
            Toy toy = null;
            switch (type.toLowerCase()) {
                case "animal" -> {
                    String material = getStringInput("Enter material: ");
                    String size = getStringInput("Enter size (S, M, L): ");
                    toy = new Animal(sn, name, brand, price, count, age, material, size);
                }
                case "figure" -> {
                    String classification = getStringInput("Enter classification: ");
                    toy = new Figure(sn, name, brand, price, count, age, classification);
                }
                case "puzzle" -> {
                    String puzzleType = getStringInput("Enter puzzle type (Mechanical, Logic, Riddle, etc.): ");
                    toy = new Puzzle(sn, name, brand, price, count, age, puzzleType);
                }
                case "boardgame" -> {
                	int minPlayers = getIntInput("Enter minimum number of players: ");
                    int maxPlayers = getIntInput("Enter maximum number of players: ");
                    
                    if (minPlayers > maxPlayers) {
                        throw new PlayerCountException("Min players cannot be greater than Max players.");
                    }
                    
                    String designers = getStringInput("Enter designer(s): ");
                    toy = new BoardGame(sn, name, brand, price, count, age, minPlayers, maxPlayers, designers);
                }
                    
                    
                default -> System.out.println("Invalid toy type!");
            }

            if (toy != null) {
                toys.add(toy);
                System.out.println("Toy added successfully!");
            }

        } catch (Exception e) {
            System.out.println("Error adding toy: " + e.getMessage());
        }
    }

    /**
     * Public class that determines how toys will get removed
     * prompts for serial number to find toy
     * asks user to confirm if they would like to delete the toy
     * removes the toy or cancels the transaction
     * 
     */
    public void removeToy() {
        String sn = getStringInput("Enter Serial Number of toy to remove: ");
        Toy toy = findToyBySN(sn);
        if (toy == null) {
            System.out.println("Toy not found.");
            return;
        }

        System.out.println("Found toy:\n" + toy);
        String confirm = getStringInput("Are you sure you want to remove this toy? (Y/N): ");
        if (confirm.equalsIgnoreCase("Y")) {
            toys.remove(toy);
            System.out.println("Toy removed successfully!");
        } else {
            System.out.println("Cancelled.");
        }
    }

    /**
     * Displays a menu that allows the user to search for suitable toy gift suggestions 
     * based on optional filtering criteria such as age range, toy type, and maximum price.
     * The user can:
     *   Enter an age range to filter toys appropriate for that age.
     *   Enter a toy type (e.g., "Animal", "Figure", "Puzzle", "BoardGame") to narrow the results.
     *   Specify a maximum price to limit results within a budget.
     * After displaying the filtered toy list, the user is prompted to optionally purchase one
     * of the suggested toys. If purchased, the toy's available count is reduced by one
     * If no toys match the search criteria, a message is displayed informing the user that 
     * no suggestions were found.
     * 
     * @throws InputMismatchException if invalid numeric input is entered for the price.
     * @see Toy
     * @see #getStringInput(String)
     * @see #getIntInput(String)
     */
    public void suggestGift() {
        System.out.println("\n Gift Suggestion Menu ");
        String age = getStringInput("Enter age range (or leave blank): ");
        String type = getStringInput("Enter toy type (or leave blank): ");
        String priceInput = getStringInput("Enter max price (or leave blank): ");

        double maxPrice = 0;
        if (!priceInput.isEmpty()) {
            try {
                maxPrice = Double.parseDouble(priceInput);
            } catch (NumberFormatException e) {
                System.out.println("Invalid price. Ignoring.");
            }
        }

        List<Toy> suggestions = new ArrayList<>();
        for (Toy t : toys) {
            boolean match = true;
            if (!age.isEmpty() && !t.getAgeAppropriate().equalsIgnoreCase(age)) match = false;
            if (!type.isEmpty() && !t.getClass().getSimpleName().equalsIgnoreCase(type)) match = false;
            if (maxPrice > 0 && t.getPrice() > maxPrice) match = false;

            if (match) suggestions.add(t);
        }

        if (suggestions.isEmpty()) {
            System.out.println("No gift suggestions found.");
            return;
        }

        System.out.println("\nSuggested Toys:");
        for (int i = 0; i < suggestions.size(); i++) {
            System.out.printf("[%d] %s%n", i + 1, suggestions.get(i));
        }

        int pick = getIntInput("\nEnter number to purchase or 0 to skip: ");
        if (pick > 0 && pick <= suggestions.size()) {
            Toy selected = suggestions.get(pick - 1);
            if (selected.getAvailableCount() > 0) {
                selected.setAvailableCount(selected.getAvailableCount() - 1);
                System.out.println("Purchase successful!");
            } else {
                System.out.println("This toy is out of stock!");
            }
        }
    }

    /**
     * public class the saves and exits the file
     * if succesfully saves will let the user know
     * if doesnt succesfully save will also let the user know
     */
    public void saveAndExit() {
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_PATH))) {
            for (Toy toy : toys) {
                writer.println(toy.toRecord());
            }
            System.out.println("Toys saved successfully! Exiting...");
        } catch (IOException e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
        System.exit(0);
    }

    /**
     * Loads the toys from the toys.txt file
     * scans file for types of toys
     * has troubleshooting to make sure the file loads properly
     * shows how many toys were uploaded
     * 
     */
    private void loadToys() {
        File file = new File(FILE_PATH);
        System.out.println("Looking for file at: " + file.getAbsolutePath());
        System.out.println("File exists? " + file.exists());
        if (!file.exists()) return;

        try (Scanner reader = new Scanner(file)) {
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                String[] data = line.split(";");
                String sn = data[0];
                char typeCode = sn.charAt(0);

                switch (typeCode) {
                    case '0', '1' -> toys.add(new Figure(data[0], data[1], data[2],
                            Double.parseDouble(data[3]), Integer.parseInt(data[4]), data[5], data[6]));
                    case '2', '3' -> toys.add(new Animal(data[0], data[1], data[2],
                            Double.parseDouble(data[3]), Integer.parseInt(data[4]), data[5], data[6], data[7]));
                    case '4', '5', '6' -> toys.add(new Puzzle(data[0], data[1], data[2],
                            Double.parseDouble(data[3]), Integer.parseInt(data[4]), data[5], data[6]));
                    case '7', '8', '9' -> {
                        String[] players = data[6].split("-");
                        int minPlayers = Integer.parseInt(players[0]);
                        int maxPlayers = Integer.parseInt(players[1]);
                        toys.add(new BoardGame(
                            data[0], data[1], data[2],
                            Double.parseDouble(data[3]), Integer.parseInt(data[4]),
                            data[5], minPlayers, maxPlayers, data[7]
                        ));
                        
                    }
                    default -> System.out.println("Unknown toy type for SN: " + sn);
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading toys: " + e.getMessage());
        }
        System.out.println("Loaded " + toys.size() + " toys from file.");

    }

    /**
     * Searches for toys by using their serial number
     * @param sn
     * @return
     */
    private Toy findToyBySN(String sn) {
        for (Toy t : toys) {
            if (t.getSerialNumber().equalsIgnoreCase(sn)) return t;
        }
        return null;
    }

    /**
     * Method for user when they input an inavlid argument
     * @param msg
     * @return
     */
    private int getIntInput(String msg) {
        System.out.print(msg);
        while (!input.hasNextInt()) {
            System.out.print("Enter a valid number: ");
            input.next();
        }
        int value = input.nextInt();
        input.nextLine(); // FIX: Consume the leftover newline
        return value;
    }

    /**
     * Method for user when they input an inavlid argument
     * @param msg
     * @return
     */
    private double getDoubleInput(String msg) {
        System.out.print(msg);
        while (!input.hasNextDouble()) {
            System.out.print("Enter a valid number: ");
            input.next();
        }
        double value = input.nextDouble();
        input.nextLine(); // FIX: Consume the leftover newline
        return value;
    }

    /**
     * toString for tsmanager
     * @param msg
     * @return
     */
    private String getStringInput(String msg) {
        System.out.print(msg);
        return input.nextLine().trim(); // Only read one line
    }
    /**
     * Checks if the Serial Number is valid according to assignment rules:
     * 1. Must be exactly 10 digits long.
     * 2. Must contain only numeric digits.
     * 3. Must have the correct prefix for the toy type.
     */
    private void validateSNPrefix(String type, String sn) throws InvalidSNPreFixException {
        
        if (sn == null || !sn.matches("\\d+")) {
             throw new InvalidSNPreFixException("The Serial Number should only contain digits!");
        }
        if (sn.length() != 10) {
             throw new InvalidSNPreFixException("The Serial Number's length MUST be 10 digits!");
        }

        
        char prefix = sn.charAt(0);
        switch (type.toLowerCase()) {
            case "figure":
                if (prefix != '0' && prefix != '1') {
                    throw new InvalidSNPreFixException("SN for Figure must start with 0 or 1.");
                }
                break;
            case "animal":
                if (prefix != '2' && prefix != '3') {
                    throw new InvalidSNPreFixException("SN for Animal must start with 2 or 3.");
                }
                break;
            case "puzzle":
                if (prefix != '4' && prefix != '5' && prefix != '6') {
                    throw new InvalidSNPreFixException("SN for Puzzle must start with 4, 5, or 6.");
                }
                break;
            case "boardgame":
                if (prefix != '7' && prefix != '8' && prefix != '9') {
                    throw new InvalidSNPreFixException("SN for Board Game must start with 7, 8, or 9.");
                }
                break;
            default:
                throw new InvalidSNPreFixException("Toy type '" + type + "' is not recognized.");
        }
    }
}
