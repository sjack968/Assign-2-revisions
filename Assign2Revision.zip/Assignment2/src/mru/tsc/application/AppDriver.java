package mru.tsc.application;

import mru.tsc.controller.TSManager;
import mru.tsc.view.TSMenu;

public class AppDriver {
	
	public static void main(String[] args) {
		
		TSManager manager = new TSManager();
		TSMenu menu = new TSMenu(manager);
		menu.run();
		
		
	}

}
