package mru.tsc.model;

import mru.tsc.exceptions.InvalidSNPreFixException;
import mru.tsc.exceptions.NegativePriceException;
import mru.tsc.exceptions.PlayerCountException; // Import the new exception

public class BoardGame extends Toy {

    private int minPlayer;
    private int maxPlayer;
    private String[] designers;

    
    public BoardGame(String serialNumber, String name, String brand, double price, int availableCount,
                     String ageAppropriate, int minPlayer, int maxPlayer, String designersList) 
                     throws NegativePriceException, InvalidSNPreFixException, PlayerCountException {
        
        super(serialNumber, name, brand, price, availableCount, ageAppropriate);

      
        requirePreFix(serialNumber, new char[] {'7','8','9'});
        
        if (minPlayer <= 0 || maxPlayer <= 0) {
            throw new IllegalArgumentException("Player numbers must be positive.");
        }

       
        if (minPlayer > maxPlayer) {
            throw new PlayerCountException("Minimum players cannot exceed maximum players.");
        }

        this.minPlayer = minPlayer;
        this.maxPlayer = maxPlayer;
        
        if (designersList == null || designersList.trim().isEmpty()) {
            throw new IllegalArgumentException("Designers cannot be empty.");
        }
        this.designers = splitDesigners(designersList);
    }
    
    private String[] splitDesigners(String list) {
        String[] parts = list.split(",");
        for (int i = 0; i < parts.length; i++) {
            parts[i] = parts[i].trim();
        }
        return parts;
    }
    
    public void setMinPlayer(int minPlayer) {
        if (minPlayer <= 0)
            throw new IllegalArgumentException("Minimum players must be positive.");
        if (maxPlayer > 0 && minPlayer > maxPlayer)
            throw new IllegalArgumentException("Minimum players cannot exceed maximum players.");
        this.minPlayer = minPlayer;
    }
    
    public int getMinPlayer() {
        return minPlayer;
    }
    
    public void setMaxPlayer(int maxPlayer) {
        if (maxPlayer <= 0)
            throw new IllegalArgumentException("Maximum players must be positive.");
        if (minPlayer > 0 && maxPlayer < minPlayer)
            throw new IllegalArgumentException("Maximum players cannot be less than minimum players.");
        this.maxPlayer = maxPlayer;
    }

    public int getMaxPlayer() {
        return maxPlayer;
    }

    public String[] getDesigners() {
        return designers;
    }

    public void setDesigners(String designersList) {
        if (designersList == null || designersList.trim().isEmpty())
            throw new IllegalArgumentException("Designers cannot be empty.");
        this.designers = splitDesigners(designersList);
    }
   
    @Override
    public String toRecord() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toRecord())
          .append(";")
          .append(minPlayer).append("-").append(maxPlayer)
          .append(";");

        for (int i = 0; i < designers.length; i++) {
            sb.append(designers[i]);
            if (i < designers.length - 1) sb.append(",");
        }

        return sb.toString();
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(super.toString())
          .append("\nPlayers: ").append(minPlayer).append(" - ").append(maxPlayer)
          .append("\nDesigners: ");

        for (int i = 0; i < designers.length; i++) {
            sb.append(designers[i]);
            if (i < designers.length - 1) sb.append(", ");
        }

        return sb.toString();
    }
}