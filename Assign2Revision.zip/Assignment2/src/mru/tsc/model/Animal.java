package mru.tsc.model;

import mru.tsc.exceptions.InvalidSNPreFixException;
import mru.tsc.exceptions.NegativePriceException;


public class Animal extends Toy{

	
	private String material;
	private String size;
	
	public Animal(String serialNumber, String name, String brand, double price, int availableCount,
			String ageAppropriate, String material, String size) throws NegativePriceException, InvalidSNPreFixException {
		super(serialNumber, name, brand, price, availableCount, ageAppropriate);
		
		if (!isValidSize(size)) {
	        throw new IllegalArgumentException("Size must be S, M or L).");
	    }
		
		
		requirePreFix(serialNumber, new char [] {'2','3'});
		
		this.material = material;
		this.size =  normalizeSize(size);
	}

	public boolean isValidSize(String size) {
		
		if (size == null) 
			return false;
		
		return size.equalsIgnoreCase("S") ||
	               size.equalsIgnoreCase("M") ||
	               size.equalsIgnoreCase("L") ||
	               size.equalsIgnoreCase("Small") ||
	               size.equalsIgnoreCase("Medium") ||
	               size.equalsIgnoreCase("Large");
	}
	
	private String normalizeSize(String size) {
        if (size.equalsIgnoreCase("S")) return "Small";
        if (size.equalsIgnoreCase("M")) return "Medium";
        if (size.equalsIgnoreCase("L")) return "Large";
        return size.substring(0, 1).toUpperCase() + size.substring(1).toLowerCase();
    }
	
	
	public void setMaterial(String material) {
		this.material = material;
	}
	
	public String getMaterial() {
		return material;
	}
	
	public void setSize(String size) {
		if (!isValidSize(size))
	        throw new IllegalArgumentException("Size must be S, M or L.");
	    
		this.size = normalizeSize(size);
	}
	
	public String getSize() {
		return size;
	}
	
	 @Override
	    public String toRecord() {
		 char code = size.charAt(0);
	        return super.toRecord() + ";" + material + ";" + code;
	    }
	 
	 @Override
	 
	 public String toString() {
		 
		 return super.toString() + 
				 String.format("%nMaterial: %s%nSize: %s", material, size);
	 }
	
}