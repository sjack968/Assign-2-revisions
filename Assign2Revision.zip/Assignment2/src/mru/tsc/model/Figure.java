package mru.tsc.model;

import mru.tsc.exceptions.InvalidSNPreFixException;
import mru.tsc.exceptions.NegativePriceException;

public class Figure extends Toy {

    private String classification;

   
    public Figure(String serialNumber, String name, String brand, double price, int availableCount,
            String ageAppropriate, String classification) throws InvalidSNPreFixException, NegativePriceException {
        
        super(serialNumber, name, brand, price, availableCount, ageAppropriate);

        
        requirePreFix(serialNumber, new char[] {'0', '1'});
        
        if (!isValidClassification(classification)) {
            throw new IllegalArgumentException("Classification must be Action (A), Doll (D), or Historic (H).");
        }

        this.classification = normalizeClassification(classification);
    }

    private boolean isValidClassification(String classification) {
        return classification.equalsIgnoreCase("A") ||
               classification.equalsIgnoreCase("D") ||
               classification.equalsIgnoreCase("H") ||
               classification.equalsIgnoreCase("Action") ||
               classification.equalsIgnoreCase("Doll") ||
               classification.equalsIgnoreCase("Historic");
    }

    private String normalizeClassification(String classification) {
        if (classification.equalsIgnoreCase("A")) return "Action";
        if (classification.equalsIgnoreCase("D")) return "Doll";
        if (classification.equalsIgnoreCase("H")) return "Historic";
        return classification.substring(0, 1).toUpperCase() + classification.substring(1).toLowerCase();
    }

    public String getClassification() {
        return classification;
    }

    public void setClassification(String classification) {
        if (!isValidClassification(classification)) {
            throw new IllegalArgumentException("Classification must be Action (A), Doll (D), or Historic (H).");
        }
        this.classification = normalizeClassification(classification);
    }

    @Override
    public String toRecord() {
        char code = classification.charAt(0);
        return super.toRecord() + ";" + code;
    }

    @Override
    public String toString() {
        return super.toString() + 
                 String.format("%nClassification: %s", classification);
    }
}