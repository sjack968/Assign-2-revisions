package mru.tsc.model;

import mru.tsc.exceptions.InvalidSNPreFixException;
import mru.tsc.exceptions.NegativePriceException;

public abstract class Toy {

    private String serialNumber;
    private String name;
    private String brand;
    private double price;
    private int availableCount;
    private String ageAppropriate;
    
    public Toy(String serialNumber, String name, String brand, double price, 
            int availableCount, String ageAppropriate) throws NegativePriceException, InvalidSNPreFixException {
        
        if (!isValidSN(serialNumber)) 
        	
            throw new InvalidSNPreFixException("Serial number must be 10 digits.");
        
        if (price < 0)
        	
            throw new NegativePriceException("The price cannot be less than 0.");
        
        if (availableCount < 0)
        	
            throw new IllegalArgumentException("The Available count cannot be less than 0. ");
        
        this.serialNumber = serialNumber;
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.availableCount = availableCount;
        this.ageAppropriate = ageAppropriate;
    }
    
    public static boolean isValidSN(String serialNumber) {
        return serialNumber != null && serialNumber.matches("\\d{10}");
    }
    
    public static void requirePreFix(String serialNumber, char[] allowed) throws InvalidSNPreFixException {
        boolean isValidPrefix = false;
        
        for (char c : allowed)
            if (serialNumber.charAt(0) == c) {
                isValidPrefix = true;
                break;
            }
        if (!isValidPrefix)
            throw new InvalidSNPreFixException("This is invalid prefix for this toy type.");
    }
    
    public boolean purchaseOne() {
        if (availableCount <= 0) return false;
        availableCount--;
        return true;
    }

    public String getSerialNumber() {
        return serialNumber;
    }
    
    public String getName() {
        return name;
    }
    
    public String getBrand() {
        return brand;
    }
    
    public double getPrice() {
        return price;
    }   
    
    public int getAvailableCount() {
        return availableCount;
    }
    
    public String getAgeAppropriate() {
        return ageAppropriate;
    }
    
    public void setPrice(double price) {
        this.price = price;
    }
    
    public void setAvailableCount(int availableCount) {
        if (availableCount < 0)
            throw new IllegalArgumentException("The Available count cannot be less than 0. ");
        this.availableCount = availableCount;
    }
    
    public String toRecord() {
        return String.format("%s;%s;%s;%.2f;%d;%s",
                getSerialNumber(), getName(), getBrand(),
                getPrice(), getAvailableCount(), getAgeAppropriate());
    }
    
    public String toString() {
        return String.format("Serial Number : %s%n" +
                    "Name: %s%n" +
                    "Brand: %s%n" +
                    "Price: %.2f%n" +
                    "Available Count: %d%n" +
                    "Age Appropriate: %s",
                    serialNumber, name, brand, price, availableCount, ageAppropriate);
    }
}