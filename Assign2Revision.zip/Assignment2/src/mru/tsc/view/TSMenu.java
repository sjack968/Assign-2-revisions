package mru.tsc.view;

import java.util.Scanner;
import mru.tsc.controller.TSManager;

/**
 * The TSMenu class handles user interface interactions.
 * It communicates with TSManager to perform operations.
 */
public class TSMenu {

    private TSManager manager;
    private Scanner input;

    public TSMenu(TSManager manager) {
        this.manager = manager;
        this.input = new Scanner(System.in);
    }

    /**
     * run method displays the menu for the user to choose from
     * calls the method based on the users input
     */
    public void run() {
        int choice;
        do {
            System.out.println("\n--- Toy Store Application ---");
            System.out.println("1. Search and Purchase Toy");
            System.out.println("2. Add New Toy");
            System.out.println("3. Remove Toy");
            System.out.println("4. Suggest Gift");
            System.out.println("5. Save & Exit");
            choice = getIntInput("Enter your choice: ");

            switch (choice) {
                case 1 -> manager.searchAndPurchaseToy();
                case 2 -> manager.addToy();
                case 3 -> manager.removeToy();
                case 4 -> manager.suggestGift();
                case 5 -> manager.saveAndExit();
                default -> System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 5);
    }
    
    /**
     * Method for when the user enters an invalid input
     * @param msg
     * @return
     */
    private int getIntInput(String msg) {
        System.out.print(msg);
        while (!input.hasNextInt()) {
            System.out.print("Enter a valid number: ");
            input.next();
        }
        int value = input.nextInt(); // Reads integer, leaves \n
        input.nextLine();           // FIX: Consume the leftover newline
        return value;
    }
}
