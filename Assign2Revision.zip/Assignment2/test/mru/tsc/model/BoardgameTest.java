package mru.tsc.model;

import static org.junit.Assert.*;
import org.junit.Test;
import mru.tsc.exceptions.InvalidSNPreFixException;
import mru.tsc.exceptions.NegativePriceException;
import mru.tsc.exceptions.PlayerCountException;

public class BoardgameTest {

    @Test
    public void testValidBoardGameCreation() throws NegativePriceException, InvalidSNPreFixException, PlayerCountException {
        BoardGame g = new BoardGame(
                "7000000001",   
                "Catan",
                "Kosmos",
                49.99,
                10,
                "10+",
                3,              
                4,              
                "Klaus Teuber"  
        );

        assertEquals("7000000001", g.getSerialNumber());
        assertEquals("Catan", g.getName());
        assertEquals(3, g.getMinPlayer()); 
        assertEquals(4, g.getMaxPlayer()); 
        
      
        assertEquals("Klaus Teuber", g.getDesigners()[0]);
    }

    @Test(expected = InvalidSNPreFixException.class)
    public void testInvalidSerialPrefixThrowsException() throws NegativePriceException, InvalidSNPreFixException, PlayerCountException {
        new BoardGame(
                "5000000001",
                "Fake Game",
                "Brand",
                29.99,
                5,
                "12+",
                2,
                4,
                "Designer One"
        );
    }

    @Test(expected = NegativePriceException.class)
    public void testNegativePriceThrowsException() throws NegativePriceException, InvalidSNPreFixException, PlayerCountException {
        new BoardGame(
                "7000000002",
                "Bad Game",
                "Brand",
                -10.0,         
                5,
                "8+",
                2,
                4,
                "Designer One"
        );
    }

    @Test(expected = PlayerCountException.class)
    public void testMinPlayersGreaterThanMaxThrowsException() throws NegativePriceException, InvalidSNPreFixException, PlayerCountException {
        new BoardGame(
                "7000000003",
                "Chaos Game",
                "Brand",
                34.99,
                5,
                "8+",
                5,  // Min 5
                3,  // Max 3 (Error!)
                "Designer One"
        );
    }
}