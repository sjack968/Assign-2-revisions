package mru.tsc.model;

import static org.junit.Assert.*;
import org.junit.Test;
import mru.tsc.exceptions.InvalidSNPreFixException;
import mru.tsc.exceptions.NegativePriceException;

/**
 * Tests for the Figure class.
 */
public class FigureTest {

    @Test
    public void testValidFigureCreation() throws NegativePriceException, InvalidSNPreFixException {
       
        Figure f = new Figure("1000000001", "Spiderman", "Marvel", 24.99, 10, "6", "Action");

        assertEquals("Spiderman", f.getName());
        assertEquals("Marvel", f.getBrand());
        assertEquals(24.99, f.getPrice(), 0.001);
        assertEquals(10, f.getAvailableCount());
        assertEquals("Action", f.getClassification());
    }

    @Test(expected = InvalidSNPreFixException.class)
    public void testInvalidSerialPrefixThrowsException() throws NegativePriceException, InvalidSNPreFixException {
      
        new Figure("5000000001", "Batman", "DC", 19.99, 8, "6", "Action");
    }

    @Test(expected = NegativePriceException.class)
    public void testNegativePriceThrowsException() throws NegativePriceException, InvalidSNPreFixException {
    	
        new Figure("1000000002", "Wonder Woman", "DC", -5.0, 4, "8", "Doll");
    }
}