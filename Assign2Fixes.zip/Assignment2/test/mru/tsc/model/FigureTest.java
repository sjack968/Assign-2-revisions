package mru.tsc.model;

import static org.junit.Assert.*;


import org.junit.Test;

/**
 * Tests for the Figure class.
 */

public class FigureTest {

    @Test
    public void testValidFigureCreation() {
       
        Figure f = new Figure("1000000001", "Spiderman", "Marvel", 24.99, 10, "6", "Action");

        assertEquals("Spiderman", f.getName());
        assertEquals("Marvel", f.getBrand());
        assertEquals(24.99, f.getPrice(), 0.001);
        assertEquals(10, f.getAvailableCount());
        assertEquals("Action", f.getClassification());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidSerialPrefixThrowsException() {
        
        new Figure("5000000001", "Batman", "DC", 19.99, 8, "6", "Action");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativePriceThrowsException() {
        new Figure("1000000002", "Wonder Woman", "DC", -5.0, 4, "8", "Doll");
    }
}