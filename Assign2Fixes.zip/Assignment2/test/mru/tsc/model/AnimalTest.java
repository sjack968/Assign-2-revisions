package mru.tsc.model;

import static org.junit.Assert.*;
import org.junit.Test;

/**
 * JUnit 4 tests for the Animal class.
 *
 */
public class AnimalTest {

    @Test
    public void testValidAnimalCreation() {
      
        Animal a = new Animal("2000000001", "Teddy Bear", "Hasbro",
                              24.99, 5, "3+", "Plush", "Medium");

        assertEquals("2000000001", a.getSerialNumber());
        assertEquals("Teddy Bear", a.getName());
        assertEquals("Hasbro", a.getBrand());
        assertEquals(24.99, a.getPrice(), 0.001);
        assertEquals(5, a.getAvailableCount());
        assertEquals("Plush", a.getMaterial());
        assertEquals("Medium", a.getSize());
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidSerialPrefixThrowsException() {
       
        new Animal("5000000001", "Elephant", "Mattel",
                   29.99, 4, "5+", "Cotton", "Large");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativePriceThrowsException() {
        new Animal("2000000002", "Dog Plush", "Hasbro",
                   -5.0, 2, "3+", "Plush", "Small");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidSizeThrowsException() {
        
        new Animal("2000000003", "Cat Plush", "Hasbro",
                   15.0, 3, "3+", "Plush", "Giant");
    }
}
