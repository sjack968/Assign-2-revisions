package mru.tsc.model;

import static org.junit.Assert.*;
import org.junit.Test;
import mru.tsc.exceptions.InvalidSNPreFixException; // 1. Import added

/**
 * tests for the Puzzle class. 
 */
public class PuzzleTest {

    @Test
    public void testValidPuzzleCreation() throws InvalidSNPreFixException { // 2. Added throws clause
        Puzzle p = new Puzzle(
                "4000000001",      
                "Rubik's Cube",
                "Rubik",
                14.99,
                10,
                "8+",
                "Logic"           
        );

        assertEquals("4000000001", p.getSerialNumber());
        assertEquals("Rubik's Cube", p.getName());
        assertEquals("Rubik", p.getBrand());
        assertEquals(14.99, p.getPrice(), 0.001);
    }

    // 3. Changed expected exception to InvalidSNPreFixException
    @Test(expected = InvalidSNPreFixException.class) 
    public void testInvalidSerialPrefixThrowsException() throws InvalidSNPreFixException { // 4. Added throws clause
        new Puzzle(
                "9000000001", // This prefix is invalid for Puzzle
                "Bad Puzzle",
                "Brand",
                9.99,
                5,
                "10+",
                "Logic"
        );
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativePriceThrowsException() throws InvalidSNPreFixException { // 5. Added throws clause
        new Puzzle(
                "4000000002",
                "Broken Puzzle",
                "Brand",
                -3.0,         // negative price
                3,
                "6+",
                "Trivia"
        );
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidPuzzleTypeThrowsException() throws InvalidSNPreFixException { // 6. Added throws clause
        new Puzzle(
                "4000000003",
                "Weird Puzzle",
                "Brand",
                12.0,
                4,
                "6+",
                "UnknownType"   
        );
    }
}