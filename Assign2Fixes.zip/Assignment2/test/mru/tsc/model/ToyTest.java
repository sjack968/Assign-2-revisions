package mru.tsc.model;

import static org.junit.Assert.*;
import org.junit.Test;

public class ToyTest {

    private static class TestToy extends Toy {
        public TestToy(String serialNumber, String name, String brand,
                       double price, int availableCount, String ageAppropriate) {
            super(serialNumber, name, brand, price, availableCount, ageAppropriate);
        }
    }

    @Test
    public void testValidToyCreation() {
        Toy t = new TestToy("1234567890", "Test Toy", "TestBrand", 19.99, 5, "6+");

        assertEquals("1234567890", t.getSerialNumber());
        assertEquals("Test Toy", t.getName());
        assertEquals("TestBrand", t.getBrand());
        assertEquals(19.99, t.getPrice(), 0.001);
        assertEquals(5, t.getAvailableCount());
        
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativePriceThrowsException() {
        new TestToy("1234567890", "Bad Toy", "Brand", -1.0, 3, "6+");
    }

    @Test(expected = IllegalArgumentException.class)
    public void testInvalidSerialNumberThrowsException() {
        
        new TestToy("12345", "Bad Toy", "Brand", 10.0, 3, "6+");
    }
}
