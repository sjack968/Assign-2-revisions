package mru.tsc.model;

import static org.junit.Assert.*;
import org.junit.Test;
// 1. Import the exception so we can use it in the test class
import mru.tsc.exceptions.InvalidSNPreFixException;

/**
 * JUnit 4 tests for the BoardGame class.
 */
public class BoardgameTest {

    @Test
    public void testValidBoardGameCreation() throws InvalidSNPreFixException { // 2. Add 'throws' declaration
        BoardGame g = new BoardGame(
                "7000000001",   
                "Catan",
                "Kosmos",
                49.99,
                10,
                "10+",
                3,              
                4,              
                "Klaus Teuber"  
        );

        assertEquals("7000000001", g.getSerialNumber());
        assertEquals("Catan", g.getName());
        assertEquals("Kosmos", g.getBrand());
        assertEquals(49.99, g.getPrice(), 0.001);
        assertEquals(10, g.getAvailableCount());
        assertEquals(3, g.getMinPlayer());
        assertEquals(4, g.getMaxPlayer());
        
        // 3. FIX: getDesigners() returns an array (String[]), but we were comparing it to a single String.
        // We need to check the first element of the array instead.
        assertEquals("Klaus Teuber", g.getDesigners()[0]);
    }

    // 4. FIX: We updated the model to throw InvalidSNPreFixException for bad prefixes,
    // so we must expect that specific exception here, not IllegalArgumentException.
    @Test(expected = InvalidSNPreFixException.class)
    public void testInvalidSerialPrefixThrowsException() throws InvalidSNPreFixException { // Add 'throws'
        
        new BoardGame(
                "5000000001", // This prefix '5' is invalid for BoardGames (needs 7, 8, or 9)
                "Fake Game",
                "Brand",
                29.99,
                5,
                "12+",
                2,
                4,
                "Designer One"
        );
    }

    @Test(expected = IllegalArgumentException.class)
    public void testNegativePriceThrowsException() throws InvalidSNPreFixException { // Add 'throws'
        new BoardGame(
                "7000000002",
                "Bad Game",
                "Brand",
                -10.0,         
                5,
                "8+",
                2,
                4,
                "Designer One"
        );
    }

    @Test(expected = IllegalArgumentException.class)
    public void testMinPlayersGreaterThanMaxThrowsException() throws InvalidSNPreFixException { // Add 'throws'
        
        new BoardGame(
                "7000000003",
                "Chaos Game",
                "Brand",
                34.99,
                5,
                "8+",
                5,              
                3,              
                "Designer One, Designer Two"
        );
    }
}