package mru.tsc.model;

import mru.tsc.exceptions.InvalidSNPreFixException;

/**
 * Represents an Animal toy, which is a specific type of Toy.
 * This class adds specific attributes for material and size.
 */
public class Animal extends Toy {

	private String material;
	private String size;
	
	/**
	 * Constructor to create a new Animal toy.
	 * * @param serialNumber   The unique serial number of the toy (must start with '2' or '3').
	 * @param name           The name of the toy.
	 * @param brand          The brand of the toy.
	 * @param price          The price of the toy.
	 * @param availableCount The number of units available in stock.
	 * @param ageAppropriate The age range suitable for this toy.
	 * @param material       The material the animal is made of (e.g., Cotton, Plastic).
	 * @param size           The size of the animal (S, M, L, Small, Medium, Large).
	 */
	public Animal(String serialNumber, String name, String brand, double price, int availableCount,
			String ageAppropriate, String material, String size) {
		
		// Initialize the common attributes in the superclass (Toy)
		super(serialNumber, name, brand, price, availableCount, ageAppropriate);
		
		// Validate the size before setting it
		if (!isValidSize(size)) {
	        throw new IllegalArgumentException("Size must be S, M or L).");
	    }
		
		// Verify that the serial number starts with the correct prefix for Animals
		try {
			requirePreFix(serialNumber, new char [] {'2','3'});
		} catch (InvalidSNPreFixException e) {
			// Log the error if the prefix is invalid
			e.printStackTrace();
		}
		
		this.material = material;
		// Normalize the size string (e.g., convert "S" to "Small") before storing
		this.size =  normalizeSize(size);
	}

	/**
	 * Checks if the provided size string is valid.
	 * Accepts abbreviations (S, M, L) and full words (Small, Medium, Large).
	 * * @param size The size string to check.
	 * @return true if the size is valid, false otherwise.
	 */
	public boolean isValidSize(String size) {
		
		// Prevent NullPointerException
		if (size == null) 
			return false;
		
		// Check against all allowed variations (case-insensitive)
		return size.equalsIgnoreCase("S") ||
	               size.equalsIgnoreCase("M") ||
	               size.equalsIgnoreCase("L") ||
	               size.equalsIgnoreCase("Small") ||
	               size.equalsIgnoreCase("Medium") ||
	               size.equalsIgnoreCase("Large");
	}
	
	/**
	 * Helper method to convert size abbreviations into full words.
	 * * @param size The input size string (assumed to be valid).
	 * @return The normalized size string (e.g., "Small", "Medium", "Large").
	 */
	private String normalizeSize(String size) {
		// Convert abbreviations to full words
        if (size.equalsIgnoreCase("S")) return "Small";
        if (size.equalsIgnoreCase("M")) return "Medium";
        if (size.equalsIgnoreCase("L")) return "Large";
        
        // If it's already a full word, ensure consistent capitalization (e.g., "small" -> "Small")
        return size.substring(0, 1).toUpperCase() + size.substring(1).toLowerCase();
    }
	
	/**
	 * Sets the material of the animal toy.
	 * @param material The new material.
	 */
	public void setMaterial(String material) {
		this.material = material;
	}
	
	/**
	 * Gets the material of the animal toy.
	 * @return The material string.
	 */
	public String getMaterial() {
		return material;
	}
	
	/**
	 * Sets the size of the animal toy.
	 * Validates the input and normalizes it before setting.
	 * * @param size The new size (S, M, L, etc.).
	 * @throws IllegalArgumentException if the size is invalid.
	 */
	public void setSize(String size) {
		if (!isValidSize(size))
	        throw new IllegalArgumentException("Size must be S, M or L.");
	    
		this.size = normalizeSize(size);
	}
	
	/**
	 * Gets the size of the animal toy.
	 * @return The size string.
	 */
	public String getSize() {
		return size;
	}
	
	/**
	 * Formats the Animal object into a string suitable for file storage (database record format).
	 * Appends the material and the first letter of the size to the standard Toy record.
	 * * @return A semicolon-separated string representing the Animal.
	 */
	 @Override
	    public String toRecord() {
		 // Extract the first character of the size (e.g., 'S' from "Small") for the record
		 char code = size.charAt(0);
	        return super.toRecord() + ";" + material + ";" + code;
	    }
	 
	 /**
	  * Returns a user-friendly string representation of the Animal toy.
	  * Includes details from the superclass and specific Animal attributes.
	  * * @return A formatted string for console display.
	  */
	 @Override
	 public String toString() {
		 return super.toString() + 
				 String.format("%nMaterial: %s%nSize: %s", material, size);
	 }
	
}