package mru.tsc.model;

import mru.tsc.exceptions.InvalidSNPreFixException;

/**
 * Represents a Board Game, which is a specific type of Toy.
 * This class extends the Toy superclass to include properties specific to board games,
 * such as the number of players and the designers.
 */
public class BoardGame extends Toy {

    private int minPlayer;
    private int maxPlayer;
    private String[] designers;

    /**
     * Constructor to create a new BoardGame object.
     * * @param serialNumber   The unique serial number (must start with 7, 8, or 9).
     * @param name           The name of the board game.
     * @param brand          The brand or publisher.
     * @param price          The price of the game.
     * @param availableCount The number of copies currently in stock.
     * @param ageAppropriate The recommended age range (e.g., "12+").
     * @param minPlayer      The minimum number of players required.
     * @param maxPlayer      The maximum number of players allowed.
     * @param designersList  A single string containing designer names separated by commas.
     * @throws InvalidSNPreFixException If the serial number does not start with a valid prefix.
     */
    public BoardGame(String serialNumber, String name, String brand, double price, int availableCount,
            String ageAppropriate, int minPlayer, int maxPlayer, String designersList) throws InvalidSNPreFixException {
        
        // Pass common toy attributes to the superclass constructor
        super(serialNumber, name, brand, price, availableCount, ageAppropriate);

        // Check if the serial number starts with a valid digit for Board Games (7, 8, or 9)
        // If not, we let the exception propagate up to be handled by the caller.
        requirePreFix(serialNumber, new char[] { '7', '8', '9' });

        // Basic validation: Player counts cannot be zero or negative
        if (minPlayer <= 0 || maxPlayer <= 0) {
            throw new IllegalArgumentException("Player numbers must be positive.");
        }

        // Logic check: The minimum range cannot be higher than the maximum range
        if (minPlayer > maxPlayer) {
            throw new IllegalArgumentException("Minimum players cannot exceed maximum players.");
        }

        this.minPlayer = minPlayer;
        this.maxPlayer = maxPlayer;

        // Ensure we don't try to process a null or empty list of designers
        if (designersList == null || designersList.trim().isEmpty()) {
            throw new IllegalArgumentException("Designers cannot be empty.");
        }

        // Helper method is used here to parse the CSV string into an array
        this.designers = splitDesigners(designersList);
    }

    /**
     * Helper method to convert a comma-separated string of designers into an array.
     * It also cleans up the data by removing extra whitespace around names.
     * * @param list A string like "Designer 1, Designer 2"
     * @return An array like ["Designer 1", "Designer 2"]
     */
    private String[] splitDesigners(String list) {
        // Split the input string wherever a comma appears
        String[] parts = list.split(",");
        
        // Loop through the array to remove leading/trailing spaces from each name
        for (int i = 0; i < parts.length; i++) {
            parts[i] = parts[i].trim();
        }
        return parts;
    }

    /**
     * Sets the minimum number of players.
     * * @param minPlayer The new minimum player count.
     * @throws IllegalArgumentException If minPlayer is negative/zero or greater than the current maxPlayer.
     */
    public void setMinPlayer(int minPlayer) {
        if (minPlayer <= 0) {
            throw new IllegalArgumentException("Minimum players must be positive.");
        }
        // We must ensure the new minimum doesn't invalidate the current range
        if (maxPlayer > 0 && minPlayer > maxPlayer) {
            throw new IllegalArgumentException("Minimum players cannot exceed maximum players.");
        }
        this.minPlayer = minPlayer;
    }

    public int getMinPlayer() {
        return minPlayer;
    }

    /**
     * Sets the maximum number of players.
     * * @param maxPlayer The new maximum player count.
     * @throws IllegalArgumentException If maxPlayer is negative/zero or less than the current minPlayer.
     */
    public void setMaxPlayer(int maxPlayer) {
        if (maxPlayer <= 0) {
            throw new IllegalArgumentException("Maximum players must be positive.");
        }
        // We must ensure the new maximum isn't smaller than the starting player count
        if (minPlayer > 0 && maxPlayer < minPlayer) {
            throw new IllegalArgumentException("Maximum players cannot be less than minimum players.");
        }
        this.maxPlayer = maxPlayer;
    }

    public int getMaxPlayer() {
        return maxPlayer;
    }

    public String[] getDesigners() {
        return designers;
    }

    /**
     * Updates the list of designers using a comma-separated string.
     * * @param designersList The new list of designers (e.g., "Name A, Name B").
     */
    public void setDesigners(String designersList) {
        if (designersList == null || designersList.trim().isEmpty()) {
            throw new IllegalArgumentException("Designers cannot be empty.");
        }
        // Reuse the helper method to keep parsing logic consistent
        this.designers = splitDesigners(designersList);
    }

    /**
     * Formats the BoardGame data for saving to the database file (toys.txt).
     * Format: SerialNumber;Name;Brand;Price;Count;Age;Min-Max;Designers
     */
    @Override
    public String toRecord() {
        StringBuilder sb = new StringBuilder();
        
        // Append the standard fields from the Toy class first
        sb.append(super.toRecord())
          .append(";")
          .append(minPlayer).append("-").append(maxPlayer) // Combine min and max into a range
          .append(";");

        // Iterate through the designers array to join them with commas
        for (int i = 0; i < designers.length; i++) {
            sb.append(designers[i]);
            // Add a comma separator only if it's not the last element
            if (i < designers.length - 1) {
                sb.append(",");
            }
        }

        return sb.toString();
    }

    /**
     * Returns a formatted string representation of the BoardGame for console display.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        
        // Start with the standard toString from Toy (Serial #, Name, etc.)
        sb.append(super.toString())
          .append("\nPlayers: ").append(minPlayer).append(" - ").append(maxPlayer)
          .append("\nDesigners: ");

        // Append designers in a readable comma-separated list
        for (int i = 0; i < designers.length; i++) {
            sb.append(designers[i]);
            if (i < designers.length - 1) {
                sb.append(", ");
            }
        }

        return sb.toString();
    }
}