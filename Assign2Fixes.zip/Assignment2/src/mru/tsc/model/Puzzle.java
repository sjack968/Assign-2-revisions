package mru.tsc.model;

import mru.tsc.exceptions.InvalidSNPreFixException;

public class Puzzle extends Toy{

	private String puzzleType;
	
	public Puzzle(String serialNumber, String name, String brand, double price, int availableCount,
			String ageAppropriate, String puzzleType) throws InvalidSNPreFixException {
		super(serialNumber, name, brand, price, availableCount, ageAppropriate);
	
		requirePreFix (serialNumber, new char[] {'4','5', '6'});
		
		if (!isValidPuzzleType(puzzleType)) 
            throw new IllegalArgumentException("Puzzle type must be Mechanical, "
            		+ "Cryptic, Logic, Trivia, or Riddle.");
		
		this.puzzleType = normalizePuzzleType(puzzleType);
	}
		
		
	private boolean isValidPuzzleType(String type) {
		if (type == null) 
			return false;
		String t = type.trim().toUpperCase(); // Check for case-insensitivity
        return t.equals("MECHANICAL") || t.equals("M") ||
               t.equals("CRYPTIC") || t.equals("C") ||
               t.equals("LOGIC") || t.equals("L") ||
               t.equals("TRIVIA") || t.equals("T") ||
               t.equals("RIDDLE") || t.equals("R");
		}

	private String normalizePuzzleType(String type) {
		String t = type.trim().toUpperCase();
        if (t.equals("C") || t.equals("CRYPTIC")) return "Cryptic";
        if (t.equals("L") || t.equals("LOGIC")) return "Logic";
        if (t.equals("M") || t.equals("MECHANICAL")) return "Mechanical";
        if (t.equals("T") || t.equals("TRIVIA")) return "Trivia";
        if (t.equals("R") || t.equals("RIDDLE")) return "Riddle";
        
		return type.substring(0,1).toUpperCase() 
				 + type.substring(1).toLowerCase();
	}

	

public void setPuzzleType(String puzzleType) {
		
		if (!isValidPuzzleType(puzzleType))
            throw new IllegalArgumentException("Puzzle type must be Mechanical, "
            		+ "Cryptic, Logic, Trivia, or Riddle.");
		
		this.puzzleType = normalizePuzzleType(puzzleType); // FIX: Normalize the input
	}
	
	public String getPuzzleType() {
		return puzzleType;
	}
	@Override
	public String toRecord() {
        char code = puzzleType.toUpperCase().charAt(0); // Outputs C, L, M, T, or R
        return super.toRecord() + ";" + code;
    }

	 @Override
	 public String toString() {
	        return super.toString() +
	               String.format("%nPuzzle Type: %s", puzzleType);
	    }
	
}
