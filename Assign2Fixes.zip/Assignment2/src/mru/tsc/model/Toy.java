package mru.tsc.model;

import mru.tsc.exceptions.InvalidSNPreFixException;

/**
 * The abstract superclass for all Toy objects.
 * This class defines the common attributes and behaviors shared by all types of toys
 * (like Serial Number, Name, Brand, etc.). Because it is abstract, it cannot be
 * instantiated directly; it must be extended by specific toy types.
 */
public abstract class Toy {

	// Common attributes shared by all subclasses
	private String serialNumber;
	private String name;
	private String brand;
	private double price;
	private int availableCount;
	private String ageAppropriate;
	
	/**
	 * Constructor to initialize a Toy object.
	 * Since this class is abstract, this constructor is called via 'super()' 
	 * from the subclasses (Animal, Figure, etc.).
	 * * @param serialNumber   The unique 10-digit serial number.
	 * @param name           The name of the toy.
	 * @param brand          The brand or manufacturer.
	 * @param price          The retail price of the toy.
	 * @param availableCount The inventory count.
	 * @param ageAppropriate The recommended age range string.
	 * @throws IllegalArgumentException If inputs (like SN format or price) are invalid.
	 */
	public Toy(String serialNumber,String name, 
			String brand, double price, 
			int availableCount, String ageAppropriate) {
		
		// Validate Serial Number format immediately
		if (!isValidSN(serialNumber)) 
			throw new IllegalArgumentException("Serial number must be 10 digits.");
		
		// Sanity check: Price cannot be negative
		if (price < 0)
			throw new IllegalArgumentException("The price cannot be less than 0.");
		
		// Sanity check: Inventory count cannot be negative
		if (availableCount < 0 )
			throw new IllegalArgumentException("The Available count cannot be less than 0. ");
		
		this.serialNumber = serialNumber;
		this.name = name;
		this.brand = brand;
		this.price = price;
		this.availableCount = availableCount;
		this.ageAppropriate = ageAppropriate;
	}
	
	/**
	 * Validates if a Serial Number string matches the required format.
	 * * @param serialNumber The string to check.
	 * @return true if it is not null and contains exactly 10 digits.
	 */
	public static boolean isValidSN(String serialNumber) {
		// Use Regular Expression (Regex) to check for exactly 10 digits (\d{10})
		return serialNumber != null && 
				serialNumber.matches("\\d{10}");
	}
	
	/**
	 * Checks if the Serial Number starts with a valid prefix character for a specific toy type.
	 * This logic is placed here so all subclasses can reuse it.
	 * * @param serialNumber The SN to check.
	 * @param allowed      An array of allowed starting characters (e.g., {'0', '1'} for Figures).
	 * @throws InvalidSNPreFixException If the first digit is not in the allowed list.
	 */
	public static void requirePreFix(String serialNumber, char[] allowed) throws InvalidSNPreFixException {

		boolean isValidPrefix = false;
		
		// Iterate through the allowed characters to find a match
		for (char c : allowed)
			if (serialNumber.charAt(0) == c) {
				isValidPrefix = true;
				break;
			}
		
		// If the loop finishes without finding a match, throw our custom exception
		if (!isValidPrefix)
			throw new InvalidSNPreFixException("This is invalid prefix for this toy type.");
	}
	
	/**
	 * Decrements the available count by 1 when a toy is purchased.
	 * * @return true if purchase was successful, false if out of stock.
	 */
    public boolean purchaseOne() {
        if (availableCount <= 0) return false;
        availableCount--;
        return true;
    }

	public String getSerialNumber() {
		return serialNumber;
	}
	
	public String getName() {
		return name;
		
	}
	
	public String getBrand() {
		return brand;
	}
	
	
	public double getPrice() {
		return price;
	}	
	
	public int getAvailableCount() {
		return availableCount;
	}
	
	public String getAgeAppropriate() {
		return ageAppropriate;
	}
	
	public void setPrice(double price) {
		if (price < 0)
			throw new IllegalArgumentException("The price cannot be less than 0.");
		this.price = price;
	}
	
	public void setAvailableCount(int availableCount) {
		if (availableCount < 0 )
			throw new IllegalArgumentException("The Available count cannot be less than 0. ");
		this.availableCount = availableCount;
	}
	
	/**
	 * Formats the toy's data into a specific string format (CSV-style) 
	 * suitable for saving to the 'toys.txt' database file.
	 * * @return A semicolon-separated string of the toy's basic attributes.
	 */
	public String toRecord() {
		return String.format("%s;%s;%s;%.2f;%d;%s",
				getSerialNumber(), getName(), getBrand(),
				getPrice(), getAvailableCount(), getAgeAppropriate());
	}
	
	/**
	 * Returns a user-friendly string representation of the Toy.
	 * Used for displaying search results in the console.
	 */
	@Override
	public String toString() {
		return String.format("Serial Number : %s%n" +
			        "Name: %s%n" +
			        "Brand: %s%n" +
			        "Price: %.2f%n" +
			        "Available Count: %d%n" +
			        "Age Appropriate: %s",
			        serialNumber, name, brand, price, availableCount, ageAppropriate);
		
	}
	
}