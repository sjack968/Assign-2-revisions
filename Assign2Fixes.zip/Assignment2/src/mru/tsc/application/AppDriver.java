package mru.tsc.application;

import mru.tsc.controller.TSManager;
import mru.tsc.view.TSMenu;

/**
 * The entry point for the Toy Store Company (TSC) application.
 * This class contains the main method which initializes the system's controller
 * and view components, and then starts the application loop.
 */
public class AppDriver {
	
	/**
	 * The main method responsible for bootstrapping the application.
	 * It follows the MVC (Model-View-Controller) pattern setup by creating the controller
	 * and passing it to the view.
	 * * @param args Command-line arguments (not used in this application).
	 */
	public static void main(String[] args) {
		
		// Initialize the Controller (TSManager).
		// This object is responsible for handling business logic and managing the data (the list of toys).
		TSManager manager = new TSManager();
		
		// Initialize the View (TSMenu) and inject the Controller (manager) into it.
		// This allows the Menu to send user commands (like "Add Toy" or "Purchase") to the Manager for processing.
		TSMenu menu = new TSMenu(manager);
		
		// Start the application's main loop.
		// This keeps the program running and the menu displayed until the user chooses to exit.
		menu.run();
		
	}

}
