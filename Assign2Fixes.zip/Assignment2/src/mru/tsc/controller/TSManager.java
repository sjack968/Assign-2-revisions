package mru.tsc.controller;

import java.io.*;
import java.util.*;
import mru.tsc.model.*;

/**
 * The Controller class for the Toy Store application.
 * This class manages the list of toys, handles user input/output via the console,
 * and performs business logic such as adding, removing, and purchasing toys.
 */
public class TSManager {

    private static final String FILE_PATH = "res/toys.txt";
    private List<Toy> toys;
    private Scanner input;

    /**
     * Constructor initializes the toy list and scanner, and loads data from the file.
     */
    public TSManager() {
        toys = new ArrayList<>();
        input = new Scanner(System.in);
        loadToys();
    }

    /**
     * Handles the search and purchase workflow.
     * Allows users to search by Serial Number, Name, or Type, and then optionally purchase a result.
     */
    public void searchAndPurchaseToy() {
        System.out.println("\nSearch by:");
        System.out.println("1. Serial Number");
        System.out.println("2. Name");
        System.out.println("3. Type");
        int choice = getIntInput("Choose an option: ");

        List<Toy> results = new ArrayList<>();
        
        // Use Java Streams to filter the list based on user criteria
        switch (choice) {
            case 1 -> {
                String sn = getStringInput("Enter Serial Number: ");
                toys.stream()
                    .filter(t -> t.getSerialNumber().equalsIgnoreCase(sn))
                    .forEach(results::add);
            }
            case 2 -> {
                String name = getStringInput("Enter part of name: ");
                toys.stream()
                    .filter(t -> t.getName().toLowerCase().contains(name.toLowerCase()))
                    .forEach(results::add);
            }
            case 3 -> {
                String type = getStringInput("Enter toy type (Animal, Figure, Puzzle, BoardGame): ");
                toys.stream()
                    .filter(t -> t.getClass().getSimpleName().equalsIgnoreCase(type))
                    .forEach(results::add);
            }
            default -> {
                System.out.println("Invalid option.");
                return;
            }
        }

        if (results.isEmpty()) {
            System.out.println("No toys found.");
            return;
        }

        // Display results with an index for selection
        System.out.println("\nSearch Results:");
        for (int i = 0; i < results.size(); i++) {
            System.out.printf("[%d] %s%n", i + 1, results.get(i));
        }

        // Handle the purchase logic
        int purchaseIndex = getIntInput("\nEnter number to purchase or 0 to return: ");
        if (purchaseIndex > 0 && purchaseIndex <= results.size()) {
            Toy selected = results.get(purchaseIndex - 1);
            
            if (selected.getAvailableCount() > 0) {
                selected.setAvailableCount(selected.getAvailableCount() - 1);
                System.out.println("Purchase successful! Remaining count: " + selected.getAvailableCount());
            } else {
                System.out.println("Sorry, this toy is out of stock!");
            }
        }
    }

    /**
     * Handles adding a new toy to the inventory.
     * Prompts the user for details and ensures the Serial Number is unique before creation.
     */
    public void addToy() {
        System.out.println("\nAdding new toy:");
        String type = getStringInput("Enter type (Animal, Figure, Puzzle, BoardGame): ");
        String sn = getStringInput("Enter Serial Number: ");

        // Check if serial number is already in use
        for (Toy t : toys) {
            if (t.getSerialNumber().equalsIgnoreCase(sn)) {
                System.out.println("Error: Serial Number already exists!");
                return;
            }
        }

        String name = getStringInput("Enter name: ");
        String brand = getStringInput("Enter brand: ");
        double price = getDoubleInput("Enter price: ");
        int count = getIntInput("Enter available count: ");
        String age = getStringInput("Enter age range: ");

        try {
            Toy toy = null;
            
            // Instantiate the correct subclass based on user input
            switch (type.toLowerCase()) {
                case "animal" -> {
                    String material = getStringInput("Enter material: ");
                    String size = getStringInput("Enter size (S, M, L): ");
                    toy = new Animal(sn, name, brand, price, count, age, material, size);
                }
                case "figure" -> {
                    String classification = getStringInput("Enter classification: ");
                    toy = new Figure(sn, name, brand, price, count, age, classification);
                }
                case "puzzle" -> {
                    String puzzleType = getStringInput("Enter puzzle type (Mechanical, Logic, Riddle, etc.): ");
                    toy = new Puzzle(sn, name, brand, price, count, age, puzzleType);
                }
                case "boardgame" -> {
                    int minPlayers = getIntInput("Enter minimum number of players: ");
                    int maxPlayers = getIntInput("Enter maximum number of players: ");
                    String designers = getStringInput("Enter designer(s): ");
                    toy = new BoardGame(sn, name, brand, price, count, age, minPlayers, maxPlayers, designers);
                }
                default -> System.out.println("Invalid toy type!");
            }

            if (toy != null) {
                toys.add(toy);
                System.out.println("Toy added successfully!");
            }

        } catch (Exception e) {
            System.out.println("Error adding toy: " + e.getMessage());
        }
    }

    /**
     * Removes a toy from the inventory based on its Serial Number.
     */
    public void removeToy() {
        String sn = getStringInput("Enter Serial Number of toy to remove: ");
        Toy toy = findToyBySN(sn);
        
        if (toy == null) {
            System.out.println("Toy not found.");
            return;
        }

        System.out.println("Found toy:\n" + toy);
        String confirm = getStringInput("Are you sure you want to remove this toy? (Y/N): ");
        
        if (confirm.equalsIgnoreCase("Y")) {
            toys.remove(toy);
            System.out.println("Toy removed successfully!");
        } else {
            System.out.println("Cancelled.");
        }
    }

    /**
     * Suggests toys based on age, type, and price range.
     * Users can leave fields blank to skip that specific filter.
     */
    public void suggestGift() {
        System.out.println("\n Gift Suggestion Menu ");
        String age = getStringInput("Enter age range (or leave blank): ");
        String type = getStringInput("Enter toy type (or leave blank): ");
        String priceInput = getStringInput("Enter max price (or leave blank): ");

        double maxPrice = 0;
        if (!priceInput.isEmpty()) {
            try {
                maxPrice = Double.parseDouble(priceInput);
            } catch (NumberFormatException e) {
                System.out.println("Invalid price. Ignoring price filter.");
            }
        }

        List<Toy> suggestions = new ArrayList<>();
        
        // Manual filtering loop
        for (Toy t : toys) {
            boolean match = true;
            if (!age.isEmpty() && !t.getAgeAppropriate().equalsIgnoreCase(age)) match = false;
            if (!type.isEmpty() && !t.getClass().getSimpleName().equalsIgnoreCase(type)) match = false;
            if (maxPrice > 0 && t.getPrice() > maxPrice) match = false;

            if (match) suggestions.add(t);
        }

        if (suggestions.isEmpty()) {
            System.out.println("No gift suggestions found.");
            return;
        }

        System.out.println("\nSuggested Toys:");
        for (int i = 0; i < suggestions.size(); i++) {
            System.out.printf("[%d] %s%n", i + 1, suggestions.get(i));
        }

        // Allow purchase directly from suggestion list
        int pick = getIntInput("\nEnter number to purchase or 0 to skip: ");
        if (pick > 0 && pick <= suggestions.size()) {
            Toy selected = suggestions.get(pick - 1);
            if (selected.getAvailableCount() > 0) {
                selected.setAvailableCount(selected.getAvailableCount() - 1);
                System.out.println("Purchase successful!");
            } else {
                System.out.println("This toy is out of stock!");
            }
        }
    }

    /**
     * Saves the current list of toys back to the text file and terminates the program.
     */
    public void saveAndExit() {
        // Use try-with-resources to ensure the PrintWriter is closed automatically
        try (PrintWriter writer = new PrintWriter(new FileWriter(FILE_PATH))) {
            for (Toy toy : toys) {
                writer.println(toy.toRecord());
            }
            System.out.println("Toys saved successfully! Exiting...");
        } catch (IOException e) {
            System.out.println("Error saving file: " + e.getMessage());
        }
        System.exit(0);
    }

    /**
     * Loads toy data from the 'res/toys.txt' file.
     * Parses each line based on the Serial Number prefix to create the correct object type.
     */
    private void loadToys() {
        File file = new File(FILE_PATH);
        System.out.println("Looking for file at: " + file.getAbsolutePath());
        
        if (!file.exists()) {
            System.out.println("File not found.");
            return;
        }

        try (Scanner reader = new Scanner(file)) {
            while (reader.hasNextLine()) {
                String line = reader.nextLine();
                String[] data = line.split(";");
                String sn = data[0];
                char typeCode = sn.charAt(0);

                // Determine subclass based on the first digit of the SN
                switch (typeCode) {
                    case '0', '1' -> toys.add(new Figure(data[0], data[1], data[2],
                            Double.parseDouble(data[3]), Integer.parseInt(data[4]), data[5], data[6]));
                    case '2', '3' -> toys.add(new Animal(data[0], data[1], data[2],
                            Double.parseDouble(data[3]), Integer.parseInt(data[4]), data[5], data[6], data[7]));
                    case '4', '5', '6' -> toys.add(new Puzzle(data[0], data[1], data[2],
                            Double.parseDouble(data[3]), Integer.parseInt(data[4]), data[5], data[6]));
                    case '7', '8', '9' -> {
                        String[] players = data[6].split("-");
                        int minPlayers = Integer.parseInt(players[0]);
                        int maxPlayers = Integer.parseInt(players[1]);
                        toys.add(new BoardGame(
                            data[0], data[1], data[2],
                            Double.parseDouble(data[3]), Integer.parseInt(data[4]),
                            data[5], minPlayers, maxPlayers, data[7]
                        ));
                    }
                    default -> System.out.println("Unknown toy type for SN: " + sn);
                }
            }
        } catch (Exception e) {
            System.out.println("Error loading toys: " + e.getMessage());
        }
        System.out.println("Loaded " + toys.size() + " toys from file.");
    }

    /**
     * Helper method to find a Toy object by its serial number.
     * @param sn The serial number to search for.
     * @return The Toy object if found, or null if not found.
     */
    private Toy findToyBySN(String sn) {
        for (Toy t : toys) {
            if (t.getSerialNumber().equalsIgnoreCase(sn)) return t;
        }
        return null;
    }

    /**
     * Helper method to safely get integer input from the user.
     * Loops until a valid integer is provided to prevent crashes.
     * @param msg The prompt message to display.
     * @return The valid integer entered by the user.
     */
    private int getIntInput(String msg) {
        System.out.print(msg);
        while (!input.hasNextInt()) {
            System.out.print("Enter a valid number: ");
            input.next(); // Consume invalid input
        }
        int value = input.nextInt();
        input.nextLine(); // Clear the newline character from the buffer
        return value;
    }

    /**
     * Helper method to safely get double input from the user.
     * @param msg The prompt message to display.
     * @return The valid double entered by the user.
     */
    private double getDoubleInput(String msg) {
        System.out.print(msg);
        while (!input.hasNextDouble()) {
            System.out.print("Enter a valid number: ");
            input.next();
        }
        double value = input.nextDouble();
        input.nextLine(); // Clear the newline
        return value;
    }

    /**
     * Helper method to get a string input from the user.
     * @param msg The prompt message to display.
     * @return The trimmed string entered by the user.
     */
    private String getStringInput(String msg) {
        System.out.print(msg);
        return input.nextLine().trim();
    }
}